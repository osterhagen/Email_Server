import cs180.net.Socket;

import java.io.IOException;

/**
 * Created by osterhagen on 4/14/16.
 */
public class OnlineEmailServer extends EmailServer {
    public OnlineEmailServer(String filename, int port) throws IOException {
        //TODO implement constructor
    }

    @Override
    public void run() {
        //TODO implement
    }

    public void processClient(Socket client) throws IOException {
        // Handle processing a client's request (input and output)
    }

    public void stop() {
        //TODO implement
    }
}
