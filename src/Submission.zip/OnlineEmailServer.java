import cs180.net.Socket;

import java.io.IOException;

/**
 * CS 180 - Project 4 (Reggie Hopton and Omar Raza)
 * Reggie - L02
 * Omar - L03
 * 4/14/16
 * OnlineEmailServer
 */
public class OnlineEmailServer extends EmailServer {
    public OnlineEmailServer(String filename, int port) throws IOException {
        //TODO implement constructor
    }

    @Override
    public void run() {
        //TODO implement
    }

    public void processClient(Socket client) throws IOException {
        // Handle processing a client's request (input and output)
    }

    public void stop() {
        //TODO implement
    }
}
